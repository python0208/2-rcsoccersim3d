import cma
import os 

std_list = [
# 0.8024586090513253,
# 108.7556110915902,
# 74.4935510327151,
# -18.294447081916328,
# 149.02400810686044,
# 77.51792538836638,
# 0.3434245549175683,
# -0.05778051267537769,
# 	0.06196439965990527,
# -49.92404794567735,
# 0.02913534549352995,
# 0.040069251483028374,
# 0.08311984252228707,
# 	14.173965772864628,
# 	99.70250710214097,
# 1.620534424237782,
# 0.8878126276949263,
# 0.7066620087173812,
# 1.2265865010025827,
# -0.1276370985800854,
# 0.23481727883696232,
# 	-0.13254176315494343,
# 1.2839211224476685,
# 0.710246393252769,
# 0.09199521532665715,
# -0.28009850961801286,
# -0.15921680247098174,

-21.878452192908963,
-107.2655684773586,
-46.03084224893723,
122.50096005151583,
36.70802042526406,
74.34964372370875,
-23.35326324263892,
-1.411851711850464,
4.8436144712052585,
-12.878536016473056,
8.73474032972045,
-2.0087222938685585,
2.4649510821897755,
-0.19721363030046984,
-0.07855676227334851,
7.790202814460635,
5.980745105156915,
0.60539945683587,

# kick_ik
# -16.155321891055568,
# -118.94574002268958,
# -49.0573368618613,
# 114.49734317000089,
# 27.093511567801276,
# 56.65895221759296,
# 5.333153982193821,
# -7.881565931921614,
# -3.103131585235596,
# -1.2098751103915228,
# 5.000775182873085,
# -6.017267272068568,
# 3.6943627753113,
# -0.16411604294659987,
# -0.08084359577763695,
# 6.483680425814427,
# 3.7629696858600292,
# 1.427020919469831,

]

def writeToFile(paramList, filePath):
    file = open(filePath, 'r+')
    paramLines = file.readlines()
    file.close()
    paramNames = [i.split()[0] for i in paramLines]

    newLines = []
    for i in range(len(paramNames)):
        newLines.append(paramNames[i]+'\t'+str(paramList[i])+"\n")
    file = open(filePath,'w+')
    file.writelines(newLines)
    file.close()

def run(paramList,roboType,absPath):
    writeToFile(paramList,'../paramfiles/optimizing.txt')
    command1 = './sample_start-optimization.sh {0} {1} ./out'.format(roboType,absPath)
    os.system(command1)
    command2 = 'pkill -9 rcss'
    os.system(command2)
    file = open('./out')
    lines = file.readlines()
    file.close()
    os.remove('out')
    rst = lines[0]
    print('rst',rst)
    return float(rst)

def eva(ind):
    print(len(ind),len(std_list))
    paramList = []

    for x in range(0, len(ind)):
        paramList.append(ind[x]*std_list[x])

    score = run(paramList,1,'../paramfiles/optimizing.txt')
    file = open('./out2','a')

    newLine = []
    for i in range(len(paramList)):
        newLine.append(str(paramList[i])+',')
    newLine.append(str(score)+'\n')
    file.writelines(newLine)
    file.close()
    return 30-score

cma.fmin(eva, len(std_list)*[1.1], 0.3)
